<?php

namespace App\Notifications;

use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class TaskReviewed extends Notification
{
    public $task;

    public function __construct($task)
    {
        $this->task = $task;
    }

    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->line('Your task has been reviewed')
            ->line('Status: ' . ucfirst($this->task->status))
            ->line('Remarks: ' . ($this->task->manager_remarks ?? 'No remarks'));
    }
}