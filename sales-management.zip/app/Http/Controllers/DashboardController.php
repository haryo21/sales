<?php

namespace App\Http\Controllers;

use App\Models\Task;

class DashboardController extends Controller
{
    public function index()
    {
        $user = auth('web')->user();
        
        if ($user->isManager()) {
            // Get tasks awaiting first approval
            $pendingFirstApproval = Task::where('status', 'pending_first_approval')
                                      ->orderBy('created_at', 'desc')
                                      ->get();

            // Get tasks awaiting final approval (with proof)
            $pendingFinalApproval = Task::where('status', 'pending_final_approval')
                                      ->orderBy('updated_at', 'desc')
                                      ->get();

            // Get approved and completed tasks
            $taskHistory = Task::whereIn('status', ['approved', 'final_approved', 'completed'])
                              ->orderBy('updated_at', 'desc')
                              ->get();
                              
            return view('dashboard.manager', compact('pendingFirstApproval', 'pendingFinalApproval', 'taskHistory'));
        }
        
        $tasks = $user->tasks;
        return view('dashboard.sales', compact('tasks'));
    }
}