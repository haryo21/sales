

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Sales Dashboard</h1>
        <a href="<?php echo e(route('tasks.create')); ?>" 
           class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">
            Create New Visit Report
        </a>
    </div>

    <!-- Active Tasks Section -->
    <div class="bg-white rounded-lg shadow mb-8">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Active Tasks</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Store Info</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Visit Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sales Amount</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $tasks->where('status', '!=', 'completed'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-6 py-4">
                                <div class="space-y-1">
                                    <div class="font-medium text-gray-900"><?php echo e($task->store_name); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo e($task->store_address); ?></div>
                                    <?php if($task->sales_notes): ?>
                                        <div class="text-xs text-gray-500">Notes: <?php echo e($task->sales_notes); ?></div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-6 py-4 text-sm text-gray-500">
                                <?php echo e(\Carbon\Carbon::parse($task->visit_date)->format('M d, Y')); ?>

                            </td>
                            <td class="px-6 py-4">
                                <?php if($task->sales_amount): ?>
                                    <div class="text-sm font-medium text-green-600">
                                        Rp <?php echo e(number_format($task->sales_amount, 0, ',', '.')); ?>

                                    </div>
                                <?php else: ?>
                                    <span class="text-xs text-gray-500">Not set</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 text-sm rounded-full
                                    <?php if($task->status === 'pending_first_approval'): ?> bg-yellow-100 text-yellow-800
                                    <?php elseif($task->status === 'approved'): ?> bg-blue-100 text-blue-800
                                    <?php elseif($task->status === 'rejected'): ?> bg-red-100 text-red-800
                                    <?php elseif($task->status === 'pending_final_approval'): ?> bg-purple-100 text-purple-800
                                    <?php elseif($task->status === 'final_approved'): ?> bg-green-100 text-green-800
                                    <?php else: ?> bg-gray-100 text-gray-800
                                    <?php endif; ?>">
                                    <?php echo e(ucwords(str_replace('_', ' ', $task->status))); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <?php if($task->status === 'approved' && !$task->proof_photo): ?>
                                    <button onclick="openProofModal('<?php echo e($task->id); ?>')" 
                                            class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 text-sm">
                                        Upload Proof
                                    </button>
                                <?php elseif($task->proof_photo): ?>
                                    <div class="space-y-1">
                                        <span class="text-sm text-gray-600">Proof submitted</span>
                                        <?php if($task->manager_remarks): ?>
                                            <div class="text-xs text-gray-500">
                                                Manager's Remarks: <?php echo e($task->manager_remarks); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                                No active tasks found.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Task History Section -->
    <div class="bg-white rounded-lg shadow">
        <div class="p-6">
            <h2 class="text-xl font-semibold mb-4">Task History</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Store Info</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Visit Details</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sales Info</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status & Feedback</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $tasks->where('status', 'completed'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="px-6 py-4">
                                <div class="space-y-1">
                                    <div class="font-medium text-gray-900"><?php echo e($task->store_name); ?></div>
                                    <div class="text-sm text-gray-500"><?php echo e($task->store_address); ?></div>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="space-y-1">
                                    <div class="text-sm text-gray-600"><?php echo e(\Carbon\Carbon::parse($task->visit_date)->format('M d, Y')); ?></div>
                                    <?php if($task->proof_photo): ?>
                                        <a href="<?php echo e(Storage::url($task->proof_photo)); ?>" 
                                           target="_blank"
                                           class="text-xs text-blue-600 hover:underline">
                                            View Visit Proof
                                        </a>
                                    <?php endif; ?>
                                    <?php if($task->deal_notes): ?>
                                        <div class="text-xs text-gray-500">
                                            Deal Notes: <?php echo e($task->deal_notes); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <?php if($task->sales_amount): ?>
                                    <div class="text-sm font-medium text-green-600">
                                        Rp <?php echo e(number_format($task->sales_amount, 0, ',', '.')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if($task->sales_notes): ?>
                                    <div class="text-xs text-gray-500 mt-1">
                                        Notes: <?php echo e($task->sales_notes); ?>

                                    </div>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4">
                                <div class="space-y-2">
                                    <span class="px-2 py-1 text-sm rounded-full bg-green-100 text-green-800">
                                        Completed
                                    </span>
                                    <?php if($task->manager_remarks): ?>
                                        <div class="text-xs text-gray-500">
                                            Manager's Feedback: <?php echo e($task->manager_remarks); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" class="px-6 py-4 text-center text-gray-500">
                                No completed tasks found.
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Proof Upload Modal -->
<div id="proofModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 hidden overflow-y-auto h-full w-full z-50">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Upload Visit Proof</h3>
            <form id="proofForm" action="" method="POST" enctype="multipart/form-data" class="space-y-4">
                <?php echo csrf_field(); ?>
                <!-- Proof Photo - Required -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Proof Photo (Max 2MB) <span class="text-red-500">*</span>
                    </label>
                    <input type="file" 
                           name="proof_photo" 
                           accept="image/*"
                           required 
                           class="w-full border rounded p-2">
                    <p class="mt-1 text-xs text-gray-500">Required for visit verification</p>
                </div>

                <!-- Sales Amount - Optional -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Sales Amount (Optional)
                    </label>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <span class="text-gray-500 sm:text-sm">Rp</span>
                        </div>
                        <input type="number" 
                               name="sales_amount" 
                               min="0"
                               class="focus:ring-indigo-500 focus:border-indigo-500 block w-full pl-12 pr-12 sm:text-sm border-gray-300 rounded-md" 
                               placeholder="Enter amount (if any)">
                    </div>
                    <p class="mt-1 text-xs text-gray-500">Leave empty if no sales made</p>
                </div>

                <!-- Deal Notes - Optional -->
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Deal Notes (Optional)
                    </label>
                    <textarea name="deal_notes" 
                              rows="3" 
                              class="w-full border rounded p-2"
                              placeholder="Enter any notes about the visit or deal..."></textarea>
                    <p class="mt-1 text-xs text-gray-500">Additional information about the visit</p>
                </div>

                <!-- Error Messages -->
                <?php if($errors->any()): ?>
                <div class="bg-red-50 text-red-500 text-sm p-3 rounded">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>

                <div class="flex justify-end space-x-2 mt-6">
                    <button type="button" 
                            onclick="closeProofModal()" 
                            class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition-colors">
                        Cancel
                    </button>
                    <button type="submit" 
                            class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition-colors flex items-center">
                        <span>Submit Proof</span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function openProofModal(taskId) {
    document.getElementById('proofForm').action = `/tasks/${taskId}/update-proof`;
    document.getElementById('proofModal').classList.remove('hidden');
}

function closeProofModal() {
    document.getElementById('proofModal').classList.add('hidden');
    document.getElementById('proofForm').reset();
}

// Add loading state and basic validation
document.getElementById('proofForm').addEventListener('submit', function(e) {
    const submitButton = this.querySelector('button[type="submit"]');
    const fileInput = this.querySelector('input[name="proof_photo"]');

    // Basic validation
    if (!fileInput.files || fileInput.files.length === 0) {
        e.preventDefault();
        alert('Please select a proof photo');
        return;
    }

    // Show loading state
    submitButton.disabled = true;
    submitButton.innerHTML = '<span>Uploading...</span>';
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoyon\Music\Skripsi\CV\Project KMI\Sales\sales-management\resources\views/dashboard/sales.blade.php ENDPATH**/ ?>