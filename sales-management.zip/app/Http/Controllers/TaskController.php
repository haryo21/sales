<?php

namespace App\Http\Controllers;

use App\Models\Task;
use App\Models\User;
use App\Notifications\TaskSubmitted;
use App\Notifications\TaskProofUploaded;
use App\Notifications\TaskApproved;
use App\Notifications\TaskRejected;
use App\Notifications\TaskFinalApproved;
use App\Notifications\TaskCompleted;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Log;

class TaskController extends Controller
{
   public function create()
   {
       if (Auth::user()->role !== 'sales') {
           return redirect('/dashboard')->with('error', 'Unauthorized access');
       }
       return view('tasks.create');
   }

   public function store(Request $request)
   {
       if ($request->user()->role !== 'sales') {
           return redirect('/dashboard')->with('error', 'Unauthorized access');
       }

       $validated = $request->validate([
           'store_name' => 'required|string|max:255',
           'store_address' => 'required|string',
           'description' => 'required|string',
           'sales_amount' => 'nullable|numeric|min:0',
           'sales_notes' => 'nullable|string',
           'visit_date' => 'required|date'
       ]);

       try {
           $taskData = [
               'store_name' => $validated['store_name'],
               'store_address' => $validated['store_address'],
               'description' => $validated['description'],
               'visit_date' => $validated['visit_date'],
               'status' => 'pending_first_approval'
           ];

           // Add optional fields if they exist
           if ($request->filled('sales_amount')) {
               $taskData['sales_amount'] = $validated['sales_amount'];
           }

           if ($request->filled('sales_notes')) {
               $taskData['sales_notes'] = $validated['sales_notes'];
           }

           $task = auth()->user()->tasks()->create($taskData);
           
           // Notify managers of new task
           User::where('role', 'manager')->get()->each(function($manager) use ($task) {
               $manager->notify(new TaskSubmitted($task));
           });

           return redirect()->route('dashboard')->with('success', 'Visit report submitted successfully');
       } catch (\Exception $e) {
           Log::error('Failed to create task:', ['error' => $e->getMessage()]);
           return back()->with('error', 'Failed to submit report. Please try again.');
       }
   }

   public function updateProof(Request $request, Task $task)
   {
       if ($request->user()->role !== 'sales') {
           return redirect('/dashboard')->with('error', 'Unauthorized access');
       }

       $validated = $request->validate([
           'proof_photo' => 'required|image|max:2048',
           'deal_notes' => 'nullable|string',
           'sales_amount' => 'nullable|numeric|min:0'
       ]);

       try {
           if ($request->hasFile('proof_photo')) {
               // Delete old photo if exists
               if ($task->proof_photo) {
                   Storage::disk('public')->delete($task->proof_photo);
               }
               
               // Upload new photo
               $path = $request->file('proof_photo')->store('proof-photos', 'public');
               
               $updateData = [
                   'proof_photo' => $path,
                   'status' => 'pending_final_approval'
               ];

               // Add optional data if provided
               if ($request->filled('deal_notes')) {
                   $updateData['deal_notes'] = $validated['deal_notes'];
               }

               if ($request->filled('sales_amount')) {
                   $updateData['sales_amount'] = $validated['sales_amount'];
               }

               $task->update($updateData);

               // Notify managers of proof upload
               User::where('role', 'manager')->get()->each(function($manager) use ($task) {
                   $manager->notify(new TaskProofUploaded($task));
               });

               return back()->with('success', 'Proof uploaded successfully and sent for review');
           }

           return back()->with('error', 'Please upload a photo');
       } catch (\Exception $e) {
           Log::error('Proof upload failed:', ['error' => $e->getMessage()]);
           return back()->with('error', 'Failed to upload proof');
       }
   }

   public function review(Request $request, Task $task)
   {
       if ($request->user()->role !== 'manager') {
           return redirect('/dashboard')->with('error', 'Unauthorized access');
       }

       $validated = $request->validate([
           'status' => 'required|in:approved,rejected,final_approved',
           'remarks' => 'nullable|string|max:1000'
       ]);

       try {
           $previousStatus = $task->status;
           
           $task->update([
               'status' => $validated['status'],
               'manager_remarks' => $validated['remarks'] ?? null
           ]);

           // Notify sales based on review result
           switch($validated['status']) {
               case 'approved':
                   $task->sales->notify(new TaskApproved($task));
                   break;
               case 'rejected':
                   $task->sales->notify(new TaskRejected($task));
                   break;
               case 'final_approved':
                   $task->sales->notify(new TaskFinalApproved($task));
                   break;
           }

           $message = match($validated['status']) {
               'approved' => 'Task approved. Waiting for proof upload.',
               'rejected' => 'Task rejected. Sales has been notified.',
               'final_approved' => 'Task has been finally approved.',
               default => 'Task status updated.'
           };

           return back()->with('success', $message);
       } catch (\Exception $e) {
           Log::error('Review failed:', ['error' => $e->getMessage()]);
           return back()->with('error', 'Failed to review task');
       }
   }

   public function updateStatus(Request $request, Task $task)
   {
       if ($request->user()->role !== 'manager') {
           return redirect('/dashboard')->with('error', 'Unauthorized access');
       }

       $validated = $request->validate([
           'status' => 'required|in:on_process,completed'
       ]);

       try {
           $task->update([
               'status' => $validated['status'],
               'completed_at' => $validated['status'] === 'completed' ? now() : null
           ]);

           if ($validated['status'] === 'completed') {
               $task->sales->notify(new TaskCompleted($task));
           }

           return back()->with('success', 'Task status updated to ' . ucfirst($validated['status']));
       } catch (\Exception $e) {
           Log::error('Status update failed:', ['error' => $e->getMessage()]);
           return back()->with('error', 'Failed to update status');
       }
   }
}