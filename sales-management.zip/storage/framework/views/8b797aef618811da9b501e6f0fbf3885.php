

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-2xl font-bold mb-6">Manager Dashboard</h1>
    
    <!-- First Approval Section -->
    <div class="bg-white rounded-lg shadow p-6 mb-8">
        <h2 class="text-xl font-semibold mb-4">Pending Initial Approval</h2>
        <div class="space-y-4">
            <?php $__empty_1 = true; $__currentLoopData = $pendingFirstApproval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="border rounded p-4">
                <div class="flex justify-between items-start">
                    <div class="space-y-2">
                        <h3 class="font-semibold"><?php echo e($task->store_name); ?></h3>
                        <p class="text-gray-600"><?php echo e($task->description); ?></p>
                        <div class="text-sm text-gray-500">
                            <p>Visit Date: <?php echo e(\Carbon\Carbon::parse($task->visit_date)->format('M d, Y')); ?></p>
                            <p>Store Address: <?php echo e($task->store_address); ?></p>
                            <p>Submitted by: <?php echo e($task->sales->name); ?></p>
                            <p>Submitted at: <?php echo e($task->created_at->format('M d, Y H:i')); ?></p>
                        </div>
                    </div>
                    <div class="flex space-x-2">
                        <form action="<?php echo e(route('tasks.review', $task)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="approved">
                            <button type="submit" class="bg-green-600 text-white px-3 py-1 rounded text-sm">
                                Approve
                            </button>
                        </form>
                        <form action="<?php echo e(route('tasks.review', $task)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="rejected">
                            <button type="submit" class="bg-red-600 text-white px-3 py-1 rounded text-sm">
                                Reject
                            </button>
                        </form>
                    </div>
                </div>
                <!-- Remarks textarea -->
                <div class="mt-4">
                    <form action="<?php echo e(route('tasks.review', $task)); ?>" method="POST" class="flex space-x-2">
                        <?php echo csrf_field(); ?>
                        <textarea name="remarks" placeholder="Add remarks..." class="flex-1 border rounded p-2 text-sm"></textarea>
                        <button type="submit" name="status" value="rejected" class="bg-gray-600 text-white px-3 py-1 rounded text-sm">
                            Add Remarks
                        </button>
                    </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-gray-500 text-center py-4">No tasks pending initial approval</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Final Approval Section -->
<div class="bg-white rounded-lg shadow p-6 mb-8">
    <h2 class="text-xl font-semibold mb-4">Pending Final Approval (With Proof)</h2>
    <div class="space-y-6">
        <?php $__empty_1 = true; $__currentLoopData = $pendingFinalApproval; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="border rounded-lg p-6">
            <!-- Task Info and Proof Section -->
            <div class="flex flex-col md:flex-row gap-6">
                <!-- Left Side: Task Details -->
                <div class="flex-1 space-y-4">
                    <div>
                        <h3 class="text-lg font-semibold"><?php echo e($task->store_name); ?></h3>
                        <p class="text-gray-600"><?php echo e($task->store_address); ?></p>
                    </div>
                    
                    <div class="text-sm">
                        <p><span class="font-medium">Sales Person:</span> <?php echo e($task->sales->name); ?></p>
                        <p><span class="font-medium">Visit Date:</span> <?php echo e(\Carbon\Carbon::parse($task->visit_date)->format('M d, Y')); ?></p>
                        <p><span class="font-medium">Initial Approval Date:</span> <?php echo e($task->updated_at->format('M d, Y H:i')); ?></p>
                    </div>

                    <div>
                        <p class="font-medium">Visit Description:</p>
                        <p class="text-gray-600"><?php echo e($task->description); ?></p>
                    </div>

                    <div>
                        <p class="font-medium">Deal Notes:</p>
                        <p class="text-gray-600"><?php echo e($task->deal_notes ?: 'No deal notes provided'); ?></p>
                    </div>
                </div>

                <!-- Right Side: Proof Photo -->
                <div class="md:w-1/2">
                    <p class="font-medium mb-2">Proof Photo:</p>
                    <?php if($task->proof_photo): ?>
                    <div class="relative group">
                        <img src="<?php echo e(asset('storage/' . $task->proof_photo)); ?>" 
                             alt="Visit Proof" 
                             class="w-full rounded-lg shadow cursor-pointer transition-transform hover:scale-105"
                             onclick="openImageModal('<?php echo e(asset('storage/' . $task->proof_photo)); ?>', '<?php echo e($task->store_name); ?>')">
                        <div class="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span class="bg-black bg-opacity-50 text-white px-4 py-2 rounded">Click to enlarge</span>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                        <p class="text-gray-500">No proof photo uploaded</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="mt-6 flex justify-end space-x-3">
                <form action="<?php echo e(route('tasks.review', $task)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="status" value="final_approved">
                    <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                        Final Approve
                    </button>
                </form>
                <form action="<?php echo e(route('tasks.review', $task)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="status" value="rejected">
                    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">
                        Reject
                    </button>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-gray-500 text-center py-4">No tasks pending final approval</p>
        <?php endif; ?>
    </div>
</div>

<!-- Image Modal -->
<div id="imageModal" class="fixed inset-0 bg-black bg-opacity-75 hidden z-50 flex items-center justify-center">
    <div class="max-w-6xl w-full mx-4 relative">
        <div class="bg-white rounded-lg p-2">
            <div class="flex justify-between items-center mb-2 px-2">
                <h3 id="modalTitle" class="text-lg font-semibold"></h3>
                <button onclick="closeImageModal()" class="text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <img id="modalImage" src="" alt="Full size proof" class="max-h-[80vh] mx-auto rounded-lg">
        </div>
    </div>
</div>

<script>
function openImageModal(imageUrl, storeName) {
    const modal = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    const modalTitle = document.getElementById('modalTitle');
    
    modalImage.src = imageUrl;
    modalTitle.textContent = `Proof Photo - ${storeName}`;
    modal.classList.remove('hidden');
}

function closeImageModal() {
    const modal = document.getElementById('imageModal');
    modal.classList.add('hidden');
}

// Close modal when clicking outside the image
document.getElementById('imageModal').addEventListener('click', function(e) {
    if (e.target === this) {
        closeImageModal();
    }
});
</script>

    <!-- Task History Section -->
<div class="bg-white rounded-lg shadow p-6">
    <h2 class="text-xl font-semibold mb-4">Task History</h2>
    <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-50">
                <tr>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Store Details
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Sales Info
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Deal Details
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Status
                    </th>
                    <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Actions
                    </th>
                </tr>
            </thead>
            <tbody class="bg-white divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $taskHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4">
                        <div class="text-sm font-medium text-gray-900"><?php echo e($task->store_name); ?></div>
                        <div class="text-sm text-gray-500"><?php echo e($task->store_address); ?></div>
                        <div class="text-xs text-gray-500">Visit: <?php echo e($task->visit_date->format('d M Y')); ?></div>
                    </td>
                    <td class="px-6 py-4">
                        <div class="text-sm text-gray-900"><?php echo e($task->sales->name); ?></div>
                        <?php if($task->sales_amount): ?>
                            <div class="text-sm font-medium text-green-600">
                                Rp <?php echo e(number_format($task->sales_amount, 0, ',', '.')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($task->sales_notes): ?>
                            <div class="text-xs text-gray-500 mt-1">
                                Notes: <?php echo e($task->sales_notes); ?>

                            </div>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4">
                        <?php if($task->deal_status): ?>
                            <div class="text-sm font-medium 
                                <?php echo e($task->deal_status === 'closed' ? 'text-green-600' : 'text-yellow-600'); ?>">
                                <?php echo e(ucfirst($task->deal_status)); ?>

                            </div>
                        <?php endif; ?>
                        <?php if($task->deal_details): ?>
                            <div class="text-sm text-gray-500"><?php echo e($task->deal_details); ?></div>
                        <?php endif; ?>
                        <?php if($task->proof_photo): ?>
                            <a href="<?php echo e(Storage::url($task->proof_photo)); ?>" 
                               target="_blank"
                               class="text-xs text-blue-600 hover:underline">
                                View Photo
                            </a>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 text-xs rounded-full
                            <?php echo e($task->status === 'completed' ? 'bg-green-100 text-green-800' : 
                               ($task->status === 'approved' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800')); ?>">
                            <?php echo e(ucfirst($task->status)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 text-sm">
                        <button onclick="showTaskDetails('<?php echo e($task->id); ?>')"
                                class="text-indigo-600 hover:text-indigo-900">
                            View Details
                        </button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                        No task history available
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yoyon\Music\Skripsi\CV\Project KMI\Sales\sales-management\resources\views/dashboard/manager.blade.php ENDPATH**/ ?>