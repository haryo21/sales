<?php echo e($slot); ?>

<?php /**PATH C:\Users\yoyon\Music\Skripsi\CV\Project KMI\Sales\sales-management\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>