<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('tasks', function (Blueprint $table) {
            $table->id();
            $table->foreignId('sales_id')->constrained('users')->onDelete('cascade');
            $table->string('store_name');
            $table->text('store_address')->nullable();
            $table->text('description');
            $table->date('visit_date')->nullable();
            $table->string('proof_photo')->nullable();
            $table->text('deal_notes')->nullable();
            $table->string('status')->default('pending_first_approval');
            $table->text('manager_remarks')->nullable();
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('tasks');
    }
};