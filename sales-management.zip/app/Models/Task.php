<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    protected $fillable = [
        'sales_id',
        'store_name',
        'store_address',
        'description',
        'visit_date',
        'proof_photo',
        'deal_notes',
        'sales_amount', // Make sure this is included
        'status',
        'manager_remarks'
    ];

    protected $casts = [
        'visit_date' => 'date',
        'deal_date' => 'datetime',
        'sales_amount' => 'decimal:2'
    ];

    public function sales()
    {
        return $this->belongsTo(User::class, 'sales_id');
    }
}