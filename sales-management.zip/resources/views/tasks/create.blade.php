@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="max-w-2xl mx-auto">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold">Create New Visit Report</h1>
            <a href="{{ route('dashboard') }}" class="text-blue-600 hover:text-blue-800">Back to Dashboard</a>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <form action="{{ route('tasks.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                
                <div class="space-y-6">
                    <!-- Sales Name -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Sales Name
                        </label>
                        <input type="text" 
                               name="name" 
                               value="{{ auth()->user()->name }}" 
                               class="w-full px-3 py-2 border rounded-md" 
                               readonly>
                    </div>

                    <!-- Sales Email -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Sales Email
                        </label>
                        <input type="email" 
                               value="{{ auth()->user()->email }}" 
                               class="w-full px-3 py-2 border rounded-md" 
                               readonly>
                    </div>

                    <!-- Visit Date -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Visit Date
                        </label>
                        <input type="date" 
                               name="visit_date" 
                               value="{{ date('Y-m-d') }}" 
                               class="w-full px-3 py-2 border rounded-md" 
                               readonly>
                    </div>

                    <!-- Store Name -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Store Name
                        </label>
                        <input type="text" 
                               name="store_name" 
                               class="w-full px-3 py-2 border rounded-md" 
                               required>
                    </div>

                    <!-- Store Address -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Store Address
                        </label>
                        <textarea name="store_address" 
                                  rows="3" 
                                  class="w-full px-3 py-2 border rounded-md" 
                                  required></textarea>
                    </div>

                    <!-- Visit Purpose -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-2">
                            Visit Purpose
                        </label>
                        <textarea name="description" 
                                  rows="3" 
                                  class="w-full px-3 py-2 border rounded-md" 
                                  required></textarea>
                    </div>

                    <button type="submit" 
                            class="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700">
                        Submit Report
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection