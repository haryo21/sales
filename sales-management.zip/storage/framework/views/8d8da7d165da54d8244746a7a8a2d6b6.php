<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Management System</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Add Inter font for better typography -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-50 to-gray-100 min-h-screen">
    <?php if(auth()->guard()->check()): ?>
    <!-- Navigation Bar -->
    <nav class="bg-white border-b border-gray-100">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <!-- Left side -->
                <div class="flex items-center">
                    <div class="flex-shrink-0 flex items-center">
                        <!-- You can add a logo here -->
                        <div class="w-2 h-8 bg-indigo-600 rounded-full mr-3"></div>
                        <span class="text-xl font-semibold text-gray-900">
                            <?php echo e(auth()->user()->role === 'manager' ? 'Management Portal' : 'Sales Portal'); ?>

                        </span>
                    </div>
                </div>

                <!-- Right side -->
                <div class="flex items-center space-x-6">
                    <div class="flex items-center space-x-3">
                        <div class="flex flex-col items-end">
                            <span class="text-sm font-medium text-gray-900"><?php echo e(auth()->user()->name); ?></span>
                            <span class="text-xs text-gray-500 capitalize"><?php echo e(auth()->user()->role); ?></span>
                        </div>
                        <div class="h-8 w-px bg-gray-200"></div>
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <button type="submit" 
                                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-gray-700 bg-gray-50 hover:bg-gray-100 hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition-all duration-150">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                </svg>
                                Sign out
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Page Heading if needed -->
    <header class="bg-white shadow-sm">
        <div class="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
            <h1 class="text-lg font-semibold text-gray-900">
                <?php if(auth()->user()->role === 'manager'): ?>
                    Welcome back, Manager
                <?php else: ?>
                    Welcome back, <?php echo e(auth()->user()->name); ?>

                <?php endif; ?>
            </h1>
        </div>
    </header>

    <!-- Main Content with proper padding -->
    <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <!-- Content wrapper -->
        <div class="px-4 py-4 sm:px-0">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t border-gray-100 mt-auto">
        <div class="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
            <p class="text-center text-sm text-gray-500">
                © <?php echo e(date('Y')); ?> Sales Management System. All rights reserved.
            </p>
        </div>
    </footer>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\Users\yoyon\Music\Skripsi\CV\Project KMI\Sales\sales-management\resources\views/layouts/app.blade.php ENDPATH**/ ?>